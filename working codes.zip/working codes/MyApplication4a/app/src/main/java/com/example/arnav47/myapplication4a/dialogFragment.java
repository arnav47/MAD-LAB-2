package com.example.arnav47.myapplication4a;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 import android.app.DialogFragment;
 import android.os.Bundle;
 import android.view.LayoutInflater;
 import android.view.View;
 import android.view.ViewGroup;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.Toast;

 /**
 * Created by ImSam on 26/11/2017.
 */

public class dialogFragment extends DialogFragment {

    String[][] info={{"1","ABC","2017","ISE"},{"2","EFG","2014","ISE"},{"3","MNO","2018","ISE"},{"4","XYZ","2016","ISE"}};
    View rootView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView= inflater.inflate(R.layout.dialogfragment, container,
                false);
        getDialog().setTitle("DialogFragment Tutorial");
        getDialog().setCancelable(true);

        // Do something else
        Button check = (Button) rootView.findViewById(R.id.button);
        Button help = (Button) rootView.findViewById(R.id.button2);
        Button cancel = (Button) rootView.findViewById(R.id.button3);
        check.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View view) {
                                         EditText tv = (EditText) rootView.findViewById(R.id.editText);
                                         String id = tv.getText().toString();
                                         for (int i = 0; i < info.length; i++) {

                                             if (id.equals(info[i][0])) {
                                                 int year = Integer.parseInt(info[i][2]);
                                                 if (year >= 2017)
                                                     Toast.makeText(getActivity(), "Name:" + info[i][1] + " Year: " + info[i][2] + " Dept: " + info[i][3], Toast.LENGTH_SHORT).show();
                                                 else
                                                     Toast.makeText(getActivity(), "Student has left. Contact Warden", Toast.LENGTH_SHORT).show();
                                             }

                                         }
                                     }
                                 }
        );
        help.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Toast.makeText(getActivity(), "Warden will be intimated", Toast.LENGTH_SHORT).show();

                                    }
                                }
        );
        cancel.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                          getDialog().dismiss();
                                      }
                                  }
        );
        return rootView;
    }
}

