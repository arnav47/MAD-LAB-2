package com.example.arnav47.myapplication4a;



import android.app.Activity;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    String[][] info={{"1","ABC","2017","ISE"},{"2","EFG","2014","ISE"},{"3","MNO","2018","ISE"},{"4","XYZ","2016","ISE"}};

    dialogFragment df=  new dialogFragment();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            // Get the view from activity_main.xml
            setContentView(R.layout.activity_main);
            Button button = (Button) findViewById(R.id.dfragbutton);
            button.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick(View view) {
                    FragmentManager fm = MainActivity.this.getFragmentManager();
                    df.show(fm, "DF");

                }
            });
        }
        catch(Exception  e)
        {
            System.out.println(""+e);
        }
    }
}